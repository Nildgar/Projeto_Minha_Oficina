﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto
{
    public partial class Adiciona_CarroAluguer : Form
    {
        private Inicio PrincipalInicio;
        public CarroAluguer NovoCarroAluguer = null;
        public Adiciona_CarroAluguer(Inicio inicio)
        {
            InitializeComponent();
            this.PrincipalInicio = inicio;
        }

        private void ButtonAdicionaCarroAluguer_Click(object sender, EventArgs e)
        {
            if (TextBoxEstado.Text == string.Empty || TextBox1ParteMatricula.Text == string.Empty || TextBox2ParteMatricula.Text == string.Empty ||
                TextBox3ParteMatricula.Text == string.Empty || TextBoxNumChassis.Text == string.Empty || TextBoxMarca.Text == string.Empty ||
                TextBoxModelo.Text == string.Empty || TextBoxCombustivel.Text == string.Empty)
            {
                MessageBox.Show("Preencha Todos os Requisitos");
            }
            else
            {
                foreach (CarroAluguer carro in PrincipalInicio.minhaGestao.CarroSet)
                {
                    string Matricula = TextBox1ParteMatricula.Text + "-" + TextBox2ParteMatricula.Text + "-" + TextBox3ParteMatricula.Text;
                    int Verificacao = 0;
                    if (/*Matricula.Equals(carro.Matricula) || *//*nao sei se eliminarei pois nao sei se existe algum carro com matricula igual*/TextBoxNumChassis.Text.Equals(carro.NumeroChassis))
                    {
                        MessageBox.Show("Carro Já Existe: " + carro.Marca + ", " + carro.Modelo + ", " + carro.NumeroChassis + ", " + carro.Estado + ", " + carro.Matricula + ", " + carro.Combustivel);
                        Verificacao++;
                    }
                    if (Verificacao == 0)
                    {
                        NovoCarroAluguer = new CarroAluguer(
                            TextBoxEstado.Text, Matricula, TextBoxNumChassis.Text, TextBoxMarca.Text, TextBoxModelo.Text, TextBoxCombustivel.Text);
                        this.Close();
                    }
                }
            }
        }
    }
}
