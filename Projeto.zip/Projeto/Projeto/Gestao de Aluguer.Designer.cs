﻿namespace Projeto
{
    partial class Gestao_de_Aluguer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GroupBoxListaClientes = new System.Windows.Forms.GroupBox();
            this.ListBoxClientes = new System.Windows.Forms.ListBox();
            this.ButtonPesquisa = new System.Windows.Forms.Button();
            this.TextBoxPesquisa = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ToolStripMenuItemFicheiro = new System.Windows.Forms.ToolStripMenuItem();
            this.GroupBoxCliente = new System.Windows.Forms.GroupBox();
            this.LabelTotalCliente = new System.Windows.Forms.Label();
            this.LabelMoradaCliente = new System.Windows.Forms.Label();
            this.LabelNifCliente = new System.Windows.Forms.Label();
            this.LabelNomeCliente = new System.Windows.Forms.Label();
            this.GroupBoxAluguer = new System.Windows.Forms.GroupBox();
            this.ButtonRemoveAluguer = new System.Windows.Forms.Button();
            this.ButtonNovoAluguer = new System.Windows.Forms.Button();
            this.GroupBoxNovoAluguer = new System.Windows.Forms.GroupBox();
            this.GroupBoxEscolheCarro = new System.Windows.Forms.GroupBox();
            this.ButtonAdicionaCarro = new System.Windows.Forms.Button();
            this.ListBoxCarros = new System.Windows.Forms.ListBox();
            this.TextBoxValor = new System.Windows.Forms.TextBox();
            this.LabelKms = new System.Windows.Forms.Label();
            this.ButtonAdicionaAluguer = new System.Windows.Forms.Button();
            this.TextBoxKms = new System.Windows.Forms.TextBox();
            this.LabelValor = new System.Windows.Forms.Label();
            this.LabelDataFim = new System.Windows.Forms.Label();
            this.LabelDataInicio = new System.Windows.Forms.Label();
            this.ListBoxAluguer = new System.Windows.Forms.ListBox();
            this.DateTimePickerDataInicio = new System.Windows.Forms.DateTimePicker();
            this.DateTimePickerDatFim = new System.Windows.Forms.DateTimePicker();
            this.LabelAvisoInserir = new System.Windows.Forms.Label();
            this.GroupBoxListaClientes.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.GroupBoxCliente.SuspendLayout();
            this.GroupBoxAluguer.SuspendLayout();
            this.GroupBoxNovoAluguer.SuspendLayout();
            this.GroupBoxEscolheCarro.SuspendLayout();
            this.SuspendLayout();
            // 
            // GroupBoxListaClientes
            // 
            this.GroupBoxListaClientes.Controls.Add(this.ListBoxClientes);
            this.GroupBoxListaClientes.Controls.Add(this.ButtonPesquisa);
            this.GroupBoxListaClientes.Controls.Add(this.TextBoxPesquisa);
            this.GroupBoxListaClientes.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBoxListaClientes.Location = new System.Drawing.Point(12, 27);
            this.GroupBoxListaClientes.Name = "GroupBoxListaClientes";
            this.GroupBoxListaClientes.Size = new System.Drawing.Size(259, 525);
            this.GroupBoxListaClientes.TabIndex = 2;
            this.GroupBoxListaClientes.TabStop = false;
            this.GroupBoxListaClientes.Text = "Lista Clientes";
            // 
            // ListBoxClientes
            // 
            this.ListBoxClientes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ListBoxClientes.FormattingEnabled = true;
            this.ListBoxClientes.ItemHeight = 20;
            this.ListBoxClientes.Location = new System.Drawing.Point(6, 73);
            this.ListBoxClientes.Name = "ListBoxClientes";
            this.ListBoxClientes.Size = new System.Drawing.Size(247, 444);
            this.ListBoxClientes.TabIndex = 2;
            this.ListBoxClientes.SelectedIndexChanged += new System.EventHandler(this.ListBoxClientes_SelectedIndexChanged);
            // 
            // ButtonPesquisa
            // 
            this.ButtonPesquisa.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonPesquisa.Location = new System.Drawing.Point(172, 38);
            this.ButtonPesquisa.Name = "ButtonPesquisa";
            this.ButtonPesquisa.Size = new System.Drawing.Size(81, 29);
            this.ButtonPesquisa.TabIndex = 1;
            this.ButtonPesquisa.Text = "Pesquisar";
            this.ButtonPesquisa.UseVisualStyleBackColor = true;
            this.ButtonPesquisa.Click += new System.EventHandler(this.ButtonPesquisa_Click);
            // 
            // TextBoxPesquisa
            // 
            this.TextBoxPesquisa.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBoxPesquisa.Location = new System.Drawing.Point(6, 41);
            this.TextBoxPesquisa.Name = "TextBoxPesquisa";
            this.TextBoxPesquisa.Size = new System.Drawing.Size(160, 23);
            this.TextBoxPesquisa.TabIndex = 0;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItemFicheiro});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1128, 24);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // ToolStripMenuItemFicheiro
            // 
            this.ToolStripMenuItemFicheiro.Name = "ToolStripMenuItemFicheiro";
            this.ToolStripMenuItemFicheiro.Size = new System.Drawing.Size(61, 20);
            this.ToolStripMenuItemFicheiro.Text = "Ficheiro";
            // 
            // GroupBoxCliente
            // 
            this.GroupBoxCliente.Controls.Add(this.LabelTotalCliente);
            this.GroupBoxCliente.Controls.Add(this.LabelMoradaCliente);
            this.GroupBoxCliente.Controls.Add(this.LabelNifCliente);
            this.GroupBoxCliente.Controls.Add(this.LabelNomeCliente);
            this.GroupBoxCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBoxCliente.Location = new System.Drawing.Point(277, 27);
            this.GroupBoxCliente.Name = "GroupBoxCliente";
            this.GroupBoxCliente.Size = new System.Drawing.Size(838, 137);
            this.GroupBoxCliente.TabIndex = 6;
            this.GroupBoxCliente.TabStop = false;
            this.GroupBoxCliente.Text = "Cliente";
            // 
            // LabelTotalCliente
            // 
            this.LabelTotalCliente.AutoSize = true;
            this.LabelTotalCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelTotalCliente.Location = new System.Drawing.Point(641, 91);
            this.LabelTotalCliente.Name = "LabelTotalCliente";
            this.LabelTotalCliente.Size = new System.Drawing.Size(104, 25);
            this.LabelTotalCliente.TabIndex = 4;
            this.LabelTotalCliente.Text = "Total: -,--€";
            // 
            // LabelMoradaCliente
            // 
            this.LabelMoradaCliente.AutoSize = true;
            this.LabelMoradaCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelMoradaCliente.Location = new System.Drawing.Point(82, 91);
            this.LabelMoradaCliente.Name = "LabelMoradaCliente";
            this.LabelMoradaCliente.Size = new System.Drawing.Size(85, 25);
            this.LabelMoradaCliente.TabIndex = 2;
            this.LabelMoradaCliente.Text = "Morada:";
            // 
            // LabelNifCliente
            // 
            this.LabelNifCliente.AutoSize = true;
            this.LabelNifCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelNifCliente.Location = new System.Drawing.Point(641, 44);
            this.LabelNifCliente.Name = "LabelNifCliente";
            this.LabelNifCliente.Size = new System.Drawing.Size(49, 25);
            this.LabelNifCliente.TabIndex = 1;
            this.LabelNifCliente.Text = "NIF:";
            // 
            // LabelNomeCliente
            // 
            this.LabelNomeCliente.AutoSize = true;
            this.LabelNomeCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelNomeCliente.Location = new System.Drawing.Point(82, 44);
            this.LabelNomeCliente.Name = "LabelNomeCliente";
            this.LabelNomeCliente.Size = new System.Drawing.Size(70, 25);
            this.LabelNomeCliente.TabIndex = 0;
            this.LabelNomeCliente.Text = "Nome:";
            // 
            // GroupBoxAluguer
            // 
            this.GroupBoxAluguer.Controls.Add(this.ButtonRemoveAluguer);
            this.GroupBoxAluguer.Controls.Add(this.ButtonNovoAluguer);
            this.GroupBoxAluguer.Controls.Add(this.GroupBoxNovoAluguer);
            this.GroupBoxAluguer.Controls.Add(this.ListBoxAluguer);
            this.GroupBoxAluguer.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBoxAluguer.Location = new System.Drawing.Point(277, 170);
            this.GroupBoxAluguer.Name = "GroupBoxAluguer";
            this.GroupBoxAluguer.Size = new System.Drawing.Size(838, 382);
            this.GroupBoxAluguer.TabIndex = 7;
            this.GroupBoxAluguer.TabStop = false;
            this.GroupBoxAluguer.Text = "Aluguer";
            // 
            // ButtonRemoveAluguer
            // 
            this.ButtonRemoveAluguer.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonRemoveAluguer.Location = new System.Drawing.Point(6, 324);
            this.ButtonRemoveAluguer.Name = "ButtonRemoveAluguer";
            this.ButtonRemoveAluguer.Size = new System.Drawing.Size(124, 52);
            this.ButtonRemoveAluguer.TabIndex = 20;
            this.ButtonRemoveAluguer.Text = "Remover Aluguer";
            this.ButtonRemoveAluguer.UseVisualStyleBackColor = true;
            this.ButtonRemoveAluguer.Click += new System.EventHandler(this.ButtonRemoveAluguer_Click);
            // 
            // ButtonNovoAluguer
            // 
            this.ButtonNovoAluguer.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonNovoAluguer.Location = new System.Drawing.Point(143, 324);
            this.ButtonNovoAluguer.Name = "ButtonNovoAluguer";
            this.ButtonNovoAluguer.Size = new System.Drawing.Size(124, 52);
            this.ButtonNovoAluguer.TabIndex = 19;
            this.ButtonNovoAluguer.Text = "Novo Aluguer";
            this.ButtonNovoAluguer.UseVisualStyleBackColor = true;
            this.ButtonNovoAluguer.Click += new System.EventHandler(this.ButtonNovoAluguer_Click);
            // 
            // GroupBoxNovoAluguer
            // 
            this.GroupBoxNovoAluguer.Controls.Add(this.LabelAvisoInserir);
            this.GroupBoxNovoAluguer.Controls.Add(this.DateTimePickerDatFim);
            this.GroupBoxNovoAluguer.Controls.Add(this.DateTimePickerDataInicio);
            this.GroupBoxNovoAluguer.Controls.Add(this.GroupBoxEscolheCarro);
            this.GroupBoxNovoAluguer.Controls.Add(this.TextBoxValor);
            this.GroupBoxNovoAluguer.Controls.Add(this.LabelKms);
            this.GroupBoxNovoAluguer.Controls.Add(this.ButtonAdicionaAluguer);
            this.GroupBoxNovoAluguer.Controls.Add(this.TextBoxKms);
            this.GroupBoxNovoAluguer.Controls.Add(this.LabelValor);
            this.GroupBoxNovoAluguer.Controls.Add(this.LabelDataFim);
            this.GroupBoxNovoAluguer.Controls.Add(this.LabelDataInicio);
            this.GroupBoxNovoAluguer.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBoxNovoAluguer.Location = new System.Drawing.Point(273, 34);
            this.GroupBoxNovoAluguer.Name = "GroupBoxNovoAluguer";
            this.GroupBoxNovoAluguer.Size = new System.Drawing.Size(559, 342);
            this.GroupBoxNovoAluguer.TabIndex = 2;
            this.GroupBoxNovoAluguer.TabStop = false;
            this.GroupBoxNovoAluguer.Text = "Novo Aluguer";
            // 
            // GroupBoxEscolheCarro
            // 
            this.GroupBoxEscolheCarro.Controls.Add(this.ButtonAdicionaCarro);
            this.GroupBoxEscolheCarro.Controls.Add(this.ListBoxCarros);
            this.GroupBoxEscolheCarro.Location = new System.Drawing.Point(263, 34);
            this.GroupBoxEscolheCarro.Name = "GroupBoxEscolheCarro";
            this.GroupBoxEscolheCarro.Size = new System.Drawing.Size(290, 250);
            this.GroupBoxEscolheCarro.TabIndex = 22;
            this.GroupBoxEscolheCarro.TabStop = false;
            this.GroupBoxEscolheCarro.Text = "Escolher Carro";
            // 
            // ButtonAdicionaCarro
            // 
            this.ButtonAdicionaCarro.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonAdicionaCarro.Location = new System.Drawing.Point(34, 204);
            this.ButtonAdicionaCarro.Name = "ButtonAdicionaCarro";
            this.ButtonAdicionaCarro.Size = new System.Drawing.Size(222, 40);
            this.ButtonAdicionaCarro.TabIndex = 23;
            this.ButtonAdicionaCarro.Text = "Novo Carro";
            this.ButtonAdicionaCarro.UseVisualStyleBackColor = true;
            this.ButtonAdicionaCarro.Click += new System.EventHandler(this.ButtonAdicionaCarro_Click);
            // 
            // ListBoxCarros
            // 
            this.ListBoxCarros.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ListBoxCarros.FormattingEnabled = true;
            this.ListBoxCarros.ItemHeight = 20;
            this.ListBoxCarros.Location = new System.Drawing.Point(6, 34);
            this.ListBoxCarros.Name = "ListBoxCarros";
            this.ListBoxCarros.Size = new System.Drawing.Size(278, 164);
            this.ListBoxCarros.TabIndex = 0;
            // 
            // TextBoxValor
            // 
            this.TextBoxValor.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBoxValor.Location = new System.Drawing.Point(105, 244);
            this.TextBoxValor.Name = "TextBoxValor";
            this.TextBoxValor.Size = new System.Drawing.Size(146, 30);
            this.TextBoxValor.TabIndex = 21;
            // 
            // LabelKms
            // 
            this.LabelKms.AutoSize = true;
            this.LabelKms.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelKms.Location = new System.Drawing.Point(35, 299);
            this.LabelKms.Name = "LabelKms";
            this.LabelKms.Size = new System.Drawing.Size(58, 25);
            this.LabelKms.TabIndex = 20;
            this.LabelKms.Text = "Kms:";
            // 
            // ButtonAdicionaAluguer
            // 
            this.ButtonAdicionaAluguer.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonAdicionaAluguer.Location = new System.Drawing.Point(263, 292);
            this.ButtonAdicionaAluguer.Name = "ButtonAdicionaAluguer";
            this.ButtonAdicionaAluguer.Size = new System.Drawing.Size(290, 44);
            this.ButtonAdicionaAluguer.TabIndex = 17;
            this.ButtonAdicionaAluguer.Text = "Adicionar Aluguer";
            this.ButtonAdicionaAluguer.UseVisualStyleBackColor = true;
            this.ButtonAdicionaAluguer.Click += new System.EventHandler(this.ButtonAdicionaAluguer_Click);
            // 
            // TextBoxKms
            // 
            this.TextBoxKms.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBoxKms.Location = new System.Drawing.Point(99, 296);
            this.TextBoxKms.Name = "TextBoxKms";
            this.TextBoxKms.Size = new System.Drawing.Size(152, 30);
            this.TextBoxKms.TabIndex = 6;
            // 
            // LabelValor
            // 
            this.LabelValor.AutoSize = true;
            this.LabelValor.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelValor.Location = new System.Drawing.Point(35, 247);
            this.LabelValor.Name = "LabelValor";
            this.LabelValor.Size = new System.Drawing.Size(64, 25);
            this.LabelValor.TabIndex = 3;
            this.LabelValor.Text = "Valor:";
            // 
            // LabelDataFim
            // 
            this.LabelDataFim.AutoSize = true;
            this.LabelDataFim.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelDataFim.Location = new System.Drawing.Point(35, 148);
            this.LabelDataFim.Name = "LabelDataFim";
            this.LabelDataFim.Size = new System.Drawing.Size(123, 25);
            this.LabelDataFim.TabIndex = 1;
            this.LabelDataFim.Text = "Data de Fim:";
            // 
            // LabelDataInicio
            // 
            this.LabelDataInicio.AutoSize = true;
            this.LabelDataInicio.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelDataInicio.Location = new System.Drawing.Point(35, 55);
            this.LabelDataInicio.Name = "LabelDataInicio";
            this.LabelDataInicio.Size = new System.Drawing.Size(136, 25);
            this.LabelDataInicio.TabIndex = 0;
            this.LabelDataInicio.Text = "Data de Início:";
            // 
            // ListBoxAluguer
            // 
            this.ListBoxAluguer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ListBoxAluguer.FormattingEnabled = true;
            this.ListBoxAluguer.ItemHeight = 20;
            this.ListBoxAluguer.Location = new System.Drawing.Point(6, 34);
            this.ListBoxAluguer.Name = "ListBoxAluguer";
            this.ListBoxAluguer.Size = new System.Drawing.Size(261, 284);
            this.ListBoxAluguer.TabIndex = 0;
            this.ListBoxAluguer.SelectedIndexChanged += new System.EventHandler(this.ListBoxAluguer_SelectedIndexChanged);
            // 
            // DateTimePickerDataInicio
            // 
            this.DateTimePickerDataInicio.CustomFormat = "";
            this.DateTimePickerDataInicio.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DateTimePickerDataInicio.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DateTimePickerDataInicio.Location = new System.Drawing.Point(40, 94);
            this.DateTimePickerDataInicio.Name = "DateTimePickerDataInicio";
            this.DateTimePickerDataInicio.Size = new System.Drawing.Size(211, 30);
            this.DateTimePickerDataInicio.TabIndex = 23;
            // 
            // DateTimePickerDatFim
            // 
            this.DateTimePickerDatFim.CustomFormat = "";
            this.DateTimePickerDatFim.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DateTimePickerDatFim.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DateTimePickerDatFim.Location = new System.Drawing.Point(40, 188);
            this.DateTimePickerDatFim.Name = "DateTimePickerDatFim";
            this.DateTimePickerDatFim.Size = new System.Drawing.Size(211, 30);
            this.DateTimePickerDatFim.TabIndex = 24;
            // 
            // LabelAvisoInserir
            // 
            this.LabelAvisoInserir.AutoSize = true;
            this.LabelAvisoInserir.ForeColor = System.Drawing.Color.Red;
            this.LabelAvisoInserir.Location = new System.Drawing.Point(35, 26);
            this.LabelAvisoInserir.Name = "LabelAvisoInserir";
            this.LabelAvisoInserir.Size = new System.Drawing.Size(179, 29);
            this.LabelAvisoInserir.TabIndex = 21;
            this.LabelAvisoInserir.Text = "Insira os Dados";
            // 
            // Gestao_de_Aluguer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1128, 563);
            this.Controls.Add(this.GroupBoxAluguer);
            this.Controls.Add(this.GroupBoxCliente);
            this.Controls.Add(this.GroupBoxListaClientes);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Gestao_de_Aluguer";
            this.Text = "Gestao_de_Aluguer";
            this.Shown += new System.EventHandler(this.Gestao_de_Aluguer_Shown);
            this.GroupBoxListaClientes.ResumeLayout(false);
            this.GroupBoxListaClientes.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.GroupBoxCliente.ResumeLayout(false);
            this.GroupBoxCliente.PerformLayout();
            this.GroupBoxAluguer.ResumeLayout(false);
            this.GroupBoxNovoAluguer.ResumeLayout(false);
            this.GroupBoxNovoAluguer.PerformLayout();
            this.GroupBoxEscolheCarro.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox GroupBoxListaClientes;
        private System.Windows.Forms.ListBox ListBoxClientes;
        private System.Windows.Forms.Button ButtonPesquisa;
        private System.Windows.Forms.TextBox TextBoxPesquisa;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemFicheiro;
        private System.Windows.Forms.GroupBox GroupBoxCliente;
        private System.Windows.Forms.Label LabelTotalCliente;
        private System.Windows.Forms.Label LabelMoradaCliente;
        private System.Windows.Forms.Label LabelNifCliente;
        private System.Windows.Forms.Label LabelNomeCliente;
        private System.Windows.Forms.GroupBox GroupBoxAluguer;
        private System.Windows.Forms.ListBox ListBoxAluguer;
        private System.Windows.Forms.Button ButtonNovoAluguer;
        private System.Windows.Forms.GroupBox GroupBoxNovoAluguer;
        private System.Windows.Forms.Button ButtonAdicionaAluguer;
        private System.Windows.Forms.TextBox TextBoxKms;
        private System.Windows.Forms.Label LabelValor;
        private System.Windows.Forms.Label LabelDataFim;
        private System.Windows.Forms.Label LabelDataInicio;
        private System.Windows.Forms.GroupBox GroupBoxEscolheCarro;
        private System.Windows.Forms.Button ButtonAdicionaCarro;
        private System.Windows.Forms.ListBox ListBoxCarros;
        private System.Windows.Forms.TextBox TextBoxValor;
        private System.Windows.Forms.Label LabelKms;
        private System.Windows.Forms.Button ButtonRemoveAluguer;
        private System.Windows.Forms.DateTimePicker DateTimePickerDataInicio;
        private System.Windows.Forms.DateTimePicker DateTimePickerDatFim;
        private System.Windows.Forms.Label LabelAvisoInserir;
    }
}