﻿namespace Projeto
{
    partial class Adiciona_CarroAluguer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ficheiroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.GroupBoxNovoCarroAluguer = new System.Windows.Forms.GroupBox();
            this.TextBoxEstado = new System.Windows.Forms.TextBox();
            this.LabelEstado = new System.Windows.Forms.Label();
            this.LabelTraco2 = new System.Windows.Forms.Label();
            this.LabelCombustivel = new System.Windows.Forms.Label();
            this.LabelMarca = new System.Windows.Forms.Label();
            this.TextBoxCombustivel = new System.Windows.Forms.TextBox();
            this.TextBoxMarca = new System.Windows.Forms.TextBox();
            this.TextBoxNumChassis = new System.Windows.Forms.TextBox();
            this.TextBoxModelo = new System.Windows.Forms.TextBox();
            this.LabelTraco1 = new System.Windows.Forms.Label();
            this.LabelModelo = new System.Windows.Forms.Label();
            this.TextBox1ParteMatricula = new System.Windows.Forms.TextBox();
            this.TextBox3ParteMatricula = new System.Windows.Forms.TextBox();
            this.TextBox2ParteMatricula = new System.Windows.Forms.TextBox();
            this.LabelMatricula = new System.Windows.Forms.Label();
            this.LabelNumChassis = new System.Windows.Forms.Label();
            this.ButtonAdicionaCarroAluguer = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.GroupBoxNovoCarroAluguer.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ficheiroToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(603, 24);
            this.menuStrip1.TabIndex = 11;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // ficheiroToolStripMenuItem
            // 
            this.ficheiroToolStripMenuItem.Name = "ficheiroToolStripMenuItem";
            this.ficheiroToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.ficheiroToolStripMenuItem.Text = "Ficheiro";
            // 
            // GroupBoxNovoCarroAluguer
            // 
            this.GroupBoxNovoCarroAluguer.Controls.Add(this.TextBoxEstado);
            this.GroupBoxNovoCarroAluguer.Controls.Add(this.LabelEstado);
            this.GroupBoxNovoCarroAluguer.Controls.Add(this.LabelTraco2);
            this.GroupBoxNovoCarroAluguer.Controls.Add(this.LabelCombustivel);
            this.GroupBoxNovoCarroAluguer.Controls.Add(this.LabelMarca);
            this.GroupBoxNovoCarroAluguer.Controls.Add(this.TextBoxCombustivel);
            this.GroupBoxNovoCarroAluguer.Controls.Add(this.TextBoxMarca);
            this.GroupBoxNovoCarroAluguer.Controls.Add(this.TextBoxNumChassis);
            this.GroupBoxNovoCarroAluguer.Controls.Add(this.TextBoxModelo);
            this.GroupBoxNovoCarroAluguer.Controls.Add(this.LabelTraco1);
            this.GroupBoxNovoCarroAluguer.Controls.Add(this.LabelModelo);
            this.GroupBoxNovoCarroAluguer.Controls.Add(this.TextBox1ParteMatricula);
            this.GroupBoxNovoCarroAluguer.Controls.Add(this.TextBox3ParteMatricula);
            this.GroupBoxNovoCarroAluguer.Controls.Add(this.TextBox2ParteMatricula);
            this.GroupBoxNovoCarroAluguer.Controls.Add(this.LabelMatricula);
            this.GroupBoxNovoCarroAluguer.Controls.Add(this.LabelNumChassis);
            this.GroupBoxNovoCarroAluguer.Controls.Add(this.ButtonAdicionaCarroAluguer);
            this.GroupBoxNovoCarroAluguer.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBoxNovoCarroAluguer.Location = new System.Drawing.Point(12, 27);
            this.GroupBoxNovoCarroAluguer.Name = "GroupBoxNovoCarroAluguer";
            this.GroupBoxNovoCarroAluguer.Size = new System.Drawing.Size(578, 349);
            this.GroupBoxNovoCarroAluguer.TabIndex = 13;
            this.GroupBoxNovoCarroAluguer.TabStop = false;
            this.GroupBoxNovoCarroAluguer.Text = "Novo CarroAluguer";
            // 
            // TextBoxEstado
            // 
            this.TextBoxEstado.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBoxEstado.Location = new System.Drawing.Point(115, 192);
            this.TextBoxEstado.Name = "TextBoxEstado";
            this.TextBoxEstado.Size = new System.Drawing.Size(261, 30);
            this.TextBoxEstado.TabIndex = 16;
            // 
            // LabelEstado
            // 
            this.LabelEstado.AutoSize = true;
            this.LabelEstado.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelEstado.Location = new System.Drawing.Point(30, 195);
            this.LabelEstado.Name = "LabelEstado";
            this.LabelEstado.Size = new System.Drawing.Size(79, 25);
            this.LabelEstado.TabIndex = 15;
            this.LabelEstado.Text = "Estado:";
            // 
            // LabelTraco2
            // 
            this.LabelTraco2.AutoSize = true;
            this.LabelTraco2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelTraco2.Location = new System.Drawing.Point(266, 255);
            this.LabelTraco2.Name = "LabelTraco2";
            this.LabelTraco2.Size = new System.Drawing.Size(19, 25);
            this.LabelTraco2.TabIndex = 13;
            this.LabelTraco2.Text = "-";
            // 
            // LabelCombustivel
            // 
            this.LabelCombustivel.AutoSize = true;
            this.LabelCombustivel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelCombustivel.Location = new System.Drawing.Point(30, 315);
            this.LabelCombustivel.Name = "LabelCombustivel";
            this.LabelCombustivel.Size = new System.Drawing.Size(126, 25);
            this.LabelCombustivel.TabIndex = 4;
            this.LabelCombustivel.Text = "Combustivel:";
            // 
            // LabelMarca
            // 
            this.LabelMarca.AutoSize = true;
            this.LabelMarca.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelMarca.Location = new System.Drawing.Point(30, 75);
            this.LabelMarca.Name = "LabelMarca";
            this.LabelMarca.Size = new System.Drawing.Size(73, 25);
            this.LabelMarca.TabIndex = 5;
            this.LabelMarca.Text = "Marca:";
            // 
            // TextBoxCombustivel
            // 
            this.TextBoxCombustivel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBoxCombustivel.Location = new System.Drawing.Point(162, 312);
            this.TextBoxCombustivel.Name = "TextBoxCombustivel";
            this.TextBoxCombustivel.Size = new System.Drawing.Size(214, 30);
            this.TextBoxCombustivel.TabIndex = 2;
            // 
            // TextBoxMarca
            // 
            this.TextBoxMarca.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBoxMarca.Location = new System.Drawing.Point(109, 72);
            this.TextBoxMarca.Name = "TextBoxMarca";
            this.TextBoxMarca.Size = new System.Drawing.Size(158, 30);
            this.TextBoxMarca.TabIndex = 7;
            // 
            // TextBoxNumChassis
            // 
            this.TextBoxNumChassis.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBoxNumChassis.Location = new System.Drawing.Point(151, 132);
            this.TextBoxNumChassis.Name = "TextBoxNumChassis";
            this.TextBoxNumChassis.Size = new System.Drawing.Size(389, 30);
            this.TextBoxNumChassis.TabIndex = 8;
            // 
            // TextBoxModelo
            // 
            this.TextBoxModelo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBoxModelo.Location = new System.Drawing.Point(382, 72);
            this.TextBoxModelo.Name = "TextBoxModelo";
            this.TextBoxModelo.Size = new System.Drawing.Size(158, 30);
            this.TextBoxModelo.TabIndex = 6;
            // 
            // LabelTraco1
            // 
            this.LabelTraco1.AutoSize = true;
            this.LabelTraco1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelTraco1.Location = new System.Drawing.Point(187, 255);
            this.LabelTraco1.Name = "LabelTraco1";
            this.LabelTraco1.Size = new System.Drawing.Size(19, 25);
            this.LabelTraco1.TabIndex = 12;
            this.LabelTraco1.Text = "-";
            // 
            // LabelModelo
            // 
            this.LabelModelo.AutoSize = true;
            this.LabelModelo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelModelo.Location = new System.Drawing.Point(293, 75);
            this.LabelModelo.Name = "LabelModelo";
            this.LabelModelo.Size = new System.Drawing.Size(83, 25);
            this.LabelModelo.TabIndex = 3;
            this.LabelModelo.Text = "Modelo:";
            // 
            // TextBox1ParteMatricula
            // 
            this.TextBox1ParteMatricula.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBox1ParteMatricula.Location = new System.Drawing.Point(133, 252);
            this.TextBox1ParteMatricula.Name = "TextBox1ParteMatricula";
            this.TextBox1ParteMatricula.Size = new System.Drawing.Size(48, 30);
            this.TextBox1ParteMatricula.TabIndex = 11;
            this.TextBox1ParteMatricula.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TextBox3ParteMatricula
            // 
            this.TextBox3ParteMatricula.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBox3ParteMatricula.Location = new System.Drawing.Point(291, 252);
            this.TextBox3ParteMatricula.Name = "TextBox3ParteMatricula";
            this.TextBox3ParteMatricula.Size = new System.Drawing.Size(48, 30);
            this.TextBox3ParteMatricula.TabIndex = 10;
            this.TextBox3ParteMatricula.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TextBox2ParteMatricula
            // 
            this.TextBox2ParteMatricula.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBox2ParteMatricula.Location = new System.Drawing.Point(212, 252);
            this.TextBox2ParteMatricula.Name = "TextBox2ParteMatricula";
            this.TextBox2ParteMatricula.Size = new System.Drawing.Size(48, 30);
            this.TextBox2ParteMatricula.TabIndex = 9;
            this.TextBox2ParteMatricula.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // LabelMatricula
            // 
            this.LabelMatricula.AutoSize = true;
            this.LabelMatricula.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelMatricula.Location = new System.Drawing.Point(30, 255);
            this.LabelMatricula.Name = "LabelMatricula";
            this.LabelMatricula.Size = new System.Drawing.Size(97, 25);
            this.LabelMatricula.TabIndex = 8;
            this.LabelMatricula.Text = "Matricula:";
            // 
            // LabelNumChassis
            // 
            this.LabelNumChassis.AutoSize = true;
            this.LabelNumChassis.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelNumChassis.Location = new System.Drawing.Point(30, 135);
            this.LabelNumChassis.Name = "LabelNumChassis";
            this.LabelNumChassis.Size = new System.Drawing.Size(115, 25);
            this.LabelNumChassis.TabIndex = 1;
            this.LabelNumChassis.Text = "Nº Chassis:";
            // 
            // ButtonAdicionaCarroAluguer
            // 
            this.ButtonAdicionaCarroAluguer.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonAdicionaCarroAluguer.Location = new System.Drawing.Point(382, 252);
            this.ButtonAdicionaCarroAluguer.Name = "ButtonAdicionaCarroAluguer";
            this.ButtonAdicionaCarroAluguer.Size = new System.Drawing.Size(190, 90);
            this.ButtonAdicionaCarroAluguer.TabIndex = 3;
            this.ButtonAdicionaCarroAluguer.Text = "Adicionar Carro nos Alugueres";
            this.ButtonAdicionaCarroAluguer.UseVisualStyleBackColor = true;
            this.ButtonAdicionaCarroAluguer.Click += new System.EventHandler(this.ButtonAdicionaCarroAluguer_Click);
            // 
            // Adiciona_CarroAluguer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(603, 388);
            this.Controls.Add(this.GroupBoxNovoCarroAluguer);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Adiciona_CarroAluguer";
            this.Text = "Adiciona_CarroAluguer";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.GroupBoxNovoCarroAluguer.ResumeLayout(false);
            this.GroupBoxNovoCarroAluguer.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ficheiroToolStripMenuItem;
        private System.Windows.Forms.GroupBox GroupBoxNovoCarroAluguer;
        private System.Windows.Forms.TextBox TextBoxEstado;
        private System.Windows.Forms.Label LabelEstado;
        private System.Windows.Forms.Label LabelTraco2;
        private System.Windows.Forms.Label LabelCombustivel;
        private System.Windows.Forms.Label LabelMarca;
        private System.Windows.Forms.TextBox TextBoxCombustivel;
        private System.Windows.Forms.TextBox TextBoxMarca;
        private System.Windows.Forms.TextBox TextBoxNumChassis;
        private System.Windows.Forms.TextBox TextBoxModelo;
        private System.Windows.Forms.Label LabelTraco1;
        private System.Windows.Forms.Label LabelModelo;
        private System.Windows.Forms.TextBox TextBox1ParteMatricula;
        private System.Windows.Forms.TextBox TextBox3ParteMatricula;
        private System.Windows.Forms.TextBox TextBox2ParteMatricula;
        private System.Windows.Forms.Label LabelMatricula;
        private System.Windows.Forms.Label LabelNumChassis;
        private System.Windows.Forms.Button ButtonAdicionaCarroAluguer;
    }
}