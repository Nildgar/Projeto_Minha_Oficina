﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto
{
    public partial class Inicio : Form
    {
        public MinhaGestaoContainer minhaGestao = new MinhaGestaoContainer();
        public Inicio()
        {
            InitializeComponent();
            ToolStripStatusLabelNumClientes.Text = "Clientes: " + minhaGestao.ClienteSet.Count<Cliente>();
            ToolStripStatusLabelNumVendas.Text = "Total Vendas: " + minhaGestao.VendaSet.Count<Venda>();
            ToolStripStatusLabelNumAlugueres.Text = " Total Alugados: " + minhaGestao.AluguerSet.Count<Aluguer>();
        }

        private void ButtonGestaoClientes_Click(object sender, EventArgs e)
        {
            ButtonAdicionaCliente.Enabled = true;
        }

        private void ButtonGestaoOficina_Click(object sender, EventArgs e)
        {

        }

        private void ButtonGestaoAluguer_Click(object sender, EventArgs e)
        {
            Gestao_de_Aluguer NovaGestaoAluguer = new Gestao_de_Aluguer(this);
            NovaGestaoAluguer.ShowDialog();
        }

        private void ButtonGestaoVendas_Click(object sender, EventArgs e)
        {

        }

        private void ButtonAdicionaCliente_Click(object sender, EventArgs e)
        {
            Cliente NovoCliente = new Cliente();
            NovoCliente.Nome = "Samuel Cordeiro";
            NovoCliente.Nif = 34832942;
            NovoCliente.Morada = "Texugueira";
            NovoCliente.Contacto = 48375843;

            minhaGestao.ClienteSet.Add(NovoCliente);
            minhaGestao.SaveChanges();/*isto é para tirar*/

            CarroAluguer novoCarroAluguer = new CarroAluguer("Crítico", "23-OC-43", "NFCI345076345897630876786", "BMW", "E36", "Gasolina");

            Aluguer NovoAluguer = new Aluguer(Convert.ToDateTime("17-12-1997"), Convert.ToDateTime("12-05-2002"), 123, 127000);

            NovoAluguer.CarroAluguer = novoCarroAluguer;
            NovoCliente.Aluguer.Add(NovoAluguer);
            minhaGestao.SaveChanges();
            ButtonAdicionaCliente.Enabled = false;
        }

        private void TimerData_Tick(object sender, EventArgs e)
        {
            ToolStripStatusLabelDataHora.Text = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
        }
    }
}
