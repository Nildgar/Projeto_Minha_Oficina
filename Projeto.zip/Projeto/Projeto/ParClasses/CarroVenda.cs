﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto
{
    public partial class CarroVenda : Carro
    {
        public CarroVenda()
        {
        }
        public CarroVenda(string extras, string marca, string modelo, string numChassis, string combustivel)
        {
            this.Extras = extras;
            this.Marca = marca.ToUpper();
            this.Modelo = modelo;
            this.NumeroChassis = numChassis.ToUpper();
            this.Combustivel = combustivel;
        }
    }
}
