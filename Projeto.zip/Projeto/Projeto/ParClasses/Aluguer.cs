﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto
{
    public partial class Aluguer
    {
        public Aluguer()
        {

        }

        public Aluguer(DateTime Inicio, DateTime Fim, decimal valor, decimal kms)
        {
            this.DataInicio = Inicio;
            this.DataFim = Fim;
            this.Valor = valor;
            this.Kms = kms;
        }

        public void AtualizaAluguer(DateTime NovoInicio, DateTime NovoFim, decimal Novovalor, decimal Novokms)
        {
            this.DataInicio = NovoInicio;
            this.DataFim = NovoFim;
            this.Valor = Novovalor;
            this.Kms = Novokms;
        }

        public override string ToString()
        {
            return DataInicio + "  " + Valor + "€";
        }
    }
}
