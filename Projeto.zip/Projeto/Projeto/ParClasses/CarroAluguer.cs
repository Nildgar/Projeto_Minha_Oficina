﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto
{
    public partial class CarroAluguer : Carro
    {
        public CarroAluguer(string estado, string matricula, string numChassis, string marca, string modelo, string combustivel)
        {
            this.Estado = estado;
            this.Matricula = matricula.ToUpper();
            this.NumeroChassis = numChassis.ToUpper();
            this.Marca = marca;
            this.Modelo = modelo;
            this.Combustivel = combustivel;
        }
        public override string ToString()
        {
            return Matricula + "  " + Marca;
        }
    }
}
