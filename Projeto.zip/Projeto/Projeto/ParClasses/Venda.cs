﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto
{
    public partial class Venda
    {
        public Venda()
        {
        }
        public Venda(decimal valor, string estado, DateTime data, string extras, string marca, string modelo, string numChassis, string combustivel)
        {
            this.Valor = valor;
            this.Estado = estado;
            this.Data = data;
            this.CarroVenda = new CarroVenda(extras, marca, modelo, numChassis, combustivel);
        }
        public override string ToString()
        {
            return CarroVenda.Marca + " " + CarroVenda.Modelo + "  " + Valor + "€";
        }
    }
}
