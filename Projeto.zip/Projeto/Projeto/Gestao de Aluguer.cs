﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto
{
    public partial class Gestao_de_Aluguer : Form
    {
        private Inicio PrincipalInicio = null;
        public Gestao_de_Aluguer(Inicio inicio)
        {
            InitializeComponent();
            this.PrincipalInicio = inicio;
        }

        private void Gestao_de_Aluguer_Shown(object sender, EventArgs e)
        {
            AtualizaListBoxCliente(0);
            LimpaGroupBoxNovoAluguer();
            AtualizaListBoxCarro(-1);
        }

        public void AtualizaListBoxCliente(int Index)
        {
            if (Index > PrincipalInicio.minhaGestao.ClienteSet.Count<Cliente>())
            {
                Index = PrincipalInicio.minhaGestao.ClienteSet.Count<Cliente>();
            }
            ListBoxClientes.Items.Clear();
            ListBoxClientes.Items.Add("Nome:\r\t\t    NIF:");
            foreach (Cliente cliente in PrincipalInicio.minhaGestao.ClienteSet)
            {
                ListBoxClientes.Items.Add(cliente);
            }
            ListBoxClientes.SelectedIndex = Index;
        }

        public void AtualizaListBoxCarro(int index)
        {
            ListBoxCarros.Items.Clear();
            foreach (CarroAluguer carro in PrincipalInicio.minhaGestao.CarroSet)
            {
                ListBoxCarros.Items.Add(carro);
            }
            if (index < 0)
            {
                ListBoxCarros.SelectedItem = null;
            }
            else
            {
                if (index <= ListBoxCarros.SelectedItems.Count)
                {
                    ListBoxCarros.SelectedIndex = index;
                }
                else
                {
                    ListBoxCarros.SelectedIndex = ListBoxCarros.SelectedItems.Count;
                }
            }
        }

        private void AtualizaListBoxAluguer(Cliente cliente)
        {
            if (cliente.Aluguer.ToList() != null)
            {
                ListBoxAluguer.Items.Clear();
                foreach (Aluguer aluguer in cliente.Aluguer)
                {
                    ListBoxAluguer.Items.Add(aluguer);
                }
            }
            ListBoxCarros.SelectedItem = null;
            LabelTotalCliente.Text = "Total: " + cliente.VerificaTotal(2) + "€";
        }

        private void ListBoxClientes_SelectedIndexChanged(object sender, EventArgs e)
        {
            ListBoxCarros.SelectedItem = null;
            if (ListBoxClientes.SelectedIndex == 0)
            {
                ListBoxClientes.SelectedItem = null;
            }
            if (PrincipalInicio.minhaGestao.ClienteSet.Count<Cliente>() >= 1 && ListBoxClientes.SelectedItem != null)
            {
                Cliente ClienteSelecionado = (Cliente)ListBoxClientes.SelectedItem;
                LabelNomeCliente.Text = "Nome: " + ClienteSelecionado.Nome;
                LabelMoradaCliente.Text = "Morada: " + ClienteSelecionado.Morada;
                LabelNifCliente.Text = "NIF: " + Convert.ToString(ClienteSelecionado.Nif);
                LabelTotalCliente.Text = "Total: " + ClienteSelecionado.VerificaTotal(2) + "€";
                AtualizaListBoxAluguer(ClienteSelecionado);
            }
            else
            {
                LabelNomeCliente.Text = "Nome:";
                LabelMoradaCliente.Text = "Morada:";
                LabelNifCliente.Text = "NIF:";
                LabelTotalCliente.Text = "Total: -,--€";
            }
            LimpaGroupBoxNovoAluguer();
        }

        private void ButtonPesquisa_Click(object sender, EventArgs e)
        {
            if (TextBoxPesquisa.Text != string.Empty)
            {
                int Num = 0, Index = 0;
                string Procura = TextBoxPesquisa.Text;
                foreach (Cliente cliente in PrincipalInicio.minhaGestao.ClienteSet)
                {
                    Num++;
                    if (Convert.ToInt32(Procura) == cliente.Nif || String.Equals(Procura, cliente.Nome))
                    {
                        Index = Num;
                        break;
                    }
                }
                if (Index == 0)
                {
                    MessageBox.Show("Não foi possivel encontrar");
                }
                else
                {
                    ListBoxClientes.SelectedIndex = Index;
                }
                TextBoxPesquisa.Text = "";
            }
        }

        private void ListBoxAluguer_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ListBoxAluguer.SelectedItem != null)
            {
                Aluguer AluguerSelecionado = (Aluguer)ListBoxAluguer.SelectedItem;
                DateTimePickerDataInicio.Value = AluguerSelecionado.DataInicio;
                DateTimePickerDatFim.Value = AluguerSelecionado.DataFim;
                TextBoxValor.Text = Convert.ToString(AluguerSelecionado.Valor);
                TextBoxKms.Text = Convert.ToString(AluguerSelecionado.Kms);
                ButtonAdicionaAluguer.Text = "Guardar Alterações";
                GroupBoxNovoAluguer.Text = "Info Aluguer";
                LabelAvisoInserir.Visible = false;
                int index = 0;
                foreach (CarroAluguer carroAluguer in PrincipalInicio.minhaGestao.CarroSet)
                {
                    if (carroAluguer == AluguerSelecionado.CarroAluguer)
                    {
                        ListBoxCarros.SelectedIndex = index;
                    }
                    index++;
                }
                ButtonAdicionaAluguer.Click -= ButtonAdicionaAluguer_Click; //este remove o click atual
                ButtonAdicionaAluguer.Click += ButtonGuardaAlteracoes_Click; //este adiciona o novo click
            }
            else
            {
                LimpaGroupBoxNovoAluguer();
            }
        }

        private void ButtonRemoveAluguer_Click(object sender, EventArgs e)
        {
            if (ListBoxClientes.SelectedItem != null && ListBoxAluguer.SelectedItem != null)
            {
                Cliente ClienteSelecionado = (Cliente)ListBoxClientes.SelectedItem;
                if (ClienteSelecionado.Aluguer.Count >= 1)
                {
                    int index = ListBoxAluguer.SelectedIndex;
                    ClienteSelecionado.Aluguer.Remove((Aluguer)ListBoxAluguer.SelectedItem);
                    AtualizaListBoxAluguer(ClienteSelecionado);
                    //PrincipalInicio.minhaGestao.SaveChanges();       /* isto nao esta a guardar quando tento remover */
                }
            }
        }

        private void LimpaGroupBoxNovoAluguer()
        {
            DateTimePickerDataInicio.Value = DateTime.Now;
            DateTimePickerDatFim.Value = DateTime.Now;
            TextBoxValor.Text = "";
            TextBoxKms.Text = "";
            ButtonAdicionaAluguer.Text = "Adicionar Aluguer";
            GroupBoxNovoAluguer.Text = "Novo Aluguer";
            ListBoxCarros.SelectedItem = null;
            LabelAvisoInserir.Visible = true;
            ButtonAdicionaAluguer.Click -= ButtonGuardaAlteracoes_Click; //este remove o click atual
            ButtonAdicionaAluguer.Click += ButtonAdicionaAluguer_Click; //este adiciona o novo click
        }

        private void ButtonNovoAluguer_Click(object sender, EventArgs e)
        {
            ListBoxAluguer.SelectedItem = null;
            LimpaGroupBoxNovoAluguer();
        }

        private void ButtonAdicionaCarro_Click(object sender, EventArgs e)
        {
            Adiciona_CarroAluguer NovoAluguer = new Adiciona_CarroAluguer(PrincipalInicio);
            NovoAluguer.ShowDialog();
            PrincipalInicio.minhaGestao.CarroSet.Add(NovoAluguer.NovoCarroAluguer);
            PrincipalInicio.minhaGestao.SaveChanges();
            AtualizaListBoxCarro(ListBoxCarros.SelectedItems.Count + 1);
        }

        private void ButtonAdicionaAluguer_Click(object sender, EventArgs e)
        {
            if (ListBoxClientes.SelectedItem != null && ListBoxCarros.SelectedItem != null)
            {
                Cliente ClienteSelecionado = (Cliente)ListBoxClientes.SelectedItem;
                CarroAluguer CarroSelecionado = (CarroAluguer)ListBoxCarros.SelectedItem;
                
                Aluguer NovoAluguer = new Aluguer(
                    DateTimePickerDataInicio.Value, DateTimePickerDatFim.Value,
                    Convert.ToDecimal(TextBoxValor.Text), Convert.ToDecimal(TextBoxKms.Text));
                NovoAluguer.CarroAluguer = CarroSelecionado;
                ClienteSelecionado.Aluguer.Add(NovoAluguer);
                PrincipalInicio.minhaGestao.SaveChanges();
                AtualizaListBoxAluguer(ClienteSelecionado);
            }
        }

        private void ButtonGuardaAlteracoes_Click(object sender, EventArgs e)
        {
            if (ListBoxClientes.SelectedItem != null && ListBoxCarros.SelectedItem != null)
            {
                Cliente ClienteSelecionado = (Cliente)ListBoxClientes.SelectedItem;
                Aluguer AluguerSelecionado = (Aluguer)ListBoxAluguer.SelectedItem;
                CarroAluguer CarroSelecionado = (CarroAluguer)ListBoxCarros.SelectedItem;

                AluguerSelecionado.AtualizaAluguer(
                    DateTimePickerDataInicio.Value, DateTimePickerDatFim.Value,
                    Convert.ToDecimal(TextBoxValor.Text), Convert.ToDecimal(TextBoxKms.Text));
                AluguerSelecionado.CarroAluguer = CarroSelecionado;
                PrincipalInicio.minhaGestao.SaveChanges();
                AtualizaListBoxAluguer(ClienteSelecionado);
            }
        }
    }
}
